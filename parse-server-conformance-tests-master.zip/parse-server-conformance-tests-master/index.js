module.exports = {
  files: require('./specs/files')
}
